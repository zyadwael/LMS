import json
import os
from datetime import datetime, timedelta

from flask_admin import Admin
from flask_admin.contrib.sqla import ModelView
from flask_migrate import Migrate

import requests
from flask import Flask, render_template, redirect, url_for, flash, abort, request, current_app, jsonify, make_response, \
    Response
from sqlalchemy.orm import joinedload

from werkzeug.security import generate_password_hash, check_password_hash

from flask_sqlalchemy import SQLAlchemy

from flask_login import UserMixin, login_user, LoginManager, login_required, current_user, logout_user

from flask_babel import Babel
from werkzeug.utils import secure_filename

app = Flask(__name__)
babel = Babel(app)
login_manager = LoginManager()
login_manager.init_app(app)

UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


@login_manager.user_loader
def load_user(user_id):
    user = Users.query.get(int(user_id))
    return user


app.config['SECRET_KEY'] = 'any-key-you-choose'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

app.secret_key = 'your_secret_key'  # Required for session management and flashing

# Initialize the SQLAlchemy part of the app instance
db = SQLAlchemy(app)
migrate = Migrate(app, db)

with app.app_context():
    class Users(UserMixin, db.Model):
        id = db.Column(db.Integer, primary_key=True)
        name = db.Column(db.String(100))
        password = db.Column(db.String(100))
        email = db.Column(db.String(100), unique=True)
        gender = db.Column(db.String(100))
        religion = db.Column(db.String(100))
        role = db.Column(db.String(100))
        grade = db.Column(db.String(100))
        Class = db.Column(db.String(100))
        teacher = db.relationship('Teacher', backref='user', uselist=False)
        student = db.relationship('Students', backref='user', uselist=False)
        subjects = db.relationship('Subjects', backref='teacher')


    class Subjects(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        name = db.Column(db.String(100))
        teacher_id = db.Column(db.Integer, db.ForeignKey('users.id'))
        grade = db.Column(db.String(1000))
        teacher_name = db.Column(db.String(1000))
        lessons = db.relationship('Lessons', backref='subject')

    class Lessons(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        name = db.Column(db.String(100))
        subject_id = db.Column(db.Integer, db.ForeignKey('subjects.id'))
        files = db.relationship('Files', backref='lesson')
        videos = db.relationship('Videos', backref='lesson')
        quizzes = db.relationship('Quizzes', backref='lesson')


    class Files(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        name = db.Column(db.String(100))
        path = db.Column(db.String(200))
        lesson_id = db.Column(db.Integer, db.ForeignKey('lessons.id'))


    class Videos(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        name = db.Column(db.String(100))
        url = db.Column(db.String(200))
        lesson_id = db.Column(db.Integer, db.ForeignKey('lessons.id'))


    class Quizzes(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        name = db.Column(db.String(100))
        questions = db.Column(db.Text)  # Assuming questions are stored as JSON or similar format
        lesson_id = db.Column(db.Integer, db.ForeignKey('lessons.id'))


    class Teacher(UserMixin, db.Model):
        id = db.Column(db.Integer, primary_key=True)
        name = db.Column(db.String(100))
        email = db.Column(db.String(100))
        subject = db.Column(db.String(100))
        grade = db.Column(db.String(100))
        Class = db.Column(db.String(100))
        user_id = db.Column(db.Integer, db.ForeignKey('users.id'))


    class Students(UserMixin, db.Model):
        id = db.Column(db.Integer, primary_key=True)
        name = db.Column(db.String(100))
        email = db.Column(db.String(100))
        grade = db.Column(db.String(100))
        Class = db.Column(db.String(100))
        user_id = db.Column(db.Integer, db.ForeignKey('users.id'))


    class News(UserMixin, db.Model):
        id = db.Column(db.Integer, primary_key=True)
        title = db.Column(db.String(100))
        content = db.Column(db.String(100))


    class Posts(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        subject_name = db.Column(db.String(100))
        grade = db.Column(db.String(100))
        Class = db.Column(db.String(100))
        start_date = db.Column(db.String(100))
        end_date = db.Column(db.String(100))
        notification = db.Column(db.String(100))
        title = db.Column(db.String(100))
        content = db.Column(db.Text)
        file_path = db.Column(db.String(200))
        author_id = db.Column(db.Integer, db.ForeignKey('users.id'))
        subject_id = db.Column(db.Integer, db.ForeignKey('subjects.id'))
        author = db.relationship('Users', backref='posts')
        subject = db.relationship('Subjects', backref='posts')


    class Message(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        teacher_email = db.Column(db.String(100))
        student_email = db.Column(db.String(100))
        message = db.Column(db.Text)
        timestamp = db.Column(db.DateTime, default=datetime.utcnow)
        read = db.Column(db.Boolean, default=False)
        type = db.Column(db.String(50), default="message")
        user_id = db.Column(db.Integer, db.ForeignKey('users.id'))

        def to_dict(self):
            return {
                'id': self.id,
                'teacher_email': self.teacher_email,
                'student_email': self.student_email,
                'message': self.message,
                'timestamp': self.timestamp.isoformat(),
                'read': self.read,
                'type': self.type,
            }


    # Define the Event model
    class Event(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        title = db.Column(db.String(100))
        start_date = db.Column(db.DateTime)
        end_date = db.Column(db.DateTime)
        description = db.Column(db.Text)

        def to_dict(self):
            return {
                'id': self.id,
                'title': self.title,
                'start_date': self.start_date.isoformat(),
                'end_date': self.end_date.isoformat(),
                'description': self.description
            }


    db.create_all()


class MyModelView(ModelView):
    def is_accessible(self):
        return True


admin = Admin(app)
admin.add_view(MyModelView(Users, db.session))
admin.add_view(MyModelView(Students, db.session))
admin.add_view(MyModelView(Teacher, db.session))
admin.add_view(MyModelView(Subjects, db.session))
admin.add_view(MyModelView(Posts, db.session))
admin.add_view(MyModelView(Event, db.session))
admin.add_view(MyModelView(News, db.session))
admin.add_view(MyModelView(Message, db.session))
admin.add_view(MyModelView(Lessons, db.session))
admin.add_view(MyModelView(Quizzes, db.session))
admin.add_view(MyModelView(Files, db.session))
admin.add_view(MyModelView(Videos, db.session))

def send_notification(user_id, message_content):
    new_notification = Message(
        teacher_email=None,
        student_email=None,
        message=message_content,
        type="notification",
        read=False
    )
    new_notification.user_id = user_id
    db.session.add(new_notification)
    db.session.commit()


def get_user_notifications(user_id):
    return Message.query.filter_by(user_id=user_id, type="notification").all()


def mark_notification_as_read(notification_id):
    notification = Message.query.get(notification_id)
    if notification:
        notification.read = True
        db.session.commit()


@app.route("/", methods=['POST', 'GET'])
def login():
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")
        user = Users.query.filter_by(email=email).first()
        if user and user.password == password:
            login_user(user)
            return redirect("/dashboard")
        else:
            flash("Invalid email or password", "error")
            return redirect(url_for('login'))

    return render_template("login.html")


@app.route("/dashboard")
def dashboard():
    user = Users.query.all()
    latest_news = News.query.all()
    teachers = Teacher.query.filter_by(grade=current_user.grade).all()
    notifications = get_user_notifications(current_user.id)
    if current_user.role == "student":
        return render_template("student_dashboard.html", latest_news=latest_news, teachers=teachers,
                               notifications=notifications)
    if current_user.role == "teacher":
        return render_template("teacher_dashboard.html", latest_news=latest_news, teachers=teachers,
                               notifications=notifications)
    if current_user.role == "parent":
        return render_template("parent_dashboard.html", notifications=notifications)
    if current_user.role == "admin":
        return render_template("admin_dashboard.html", notifications=notifications)
    else:
        return redirect(url_for('unauthorized'))


@app.route('/notifications')
@login_required
def notifications():
    messages = Message.query.filter_by(student_email=current_user.email).all()
    return render_template('notifications.html', messages=messages)


@app.route('/mark_notification_as_read/<int:notification_id>', methods=['POST'])
@login_required
def mark_notification_as_read(notification_id):
    message = Message.query.get(notification_id)
    if message and message.student_email == current_user.email:
        message.read = True
        db.session.commit()
        flash('Notification marked as read.', 'success')
    else:
        flash('Notification not found or access denied.', 'error')
    return redirect(url_for(''))


# API endpoint to get all events for the dashboard
@app.route('/events', methods=['GET'])
def get_events():
    events = Event.query.all()
    return jsonify([event.to_dict() for event in events])


@app.route("/my_teachers")
def my_teachers():
    if not current_user.is_authenticated:
        # Handle case where user is not authenticated (if applicable)
        # Redirect to login page or handle as per your application's logic
        return redirect(url_for('login'))

    if current_user.role == 'student':
        filtered_subjects = Subjects.query.filter_by(grade=current_user.grade).all()
        teachers = [subject.teacher_name for subject in filtered_subjects]

        return render_template("my_teachers.html", teachers=teachers)

    # Handle other roles or scenarios (if applicable)
    return render_template("my_teachers.html", teachers=[])  # Return empty list if no teachers found


@app.route("/students")
def students():
    students = Students.query.all()
    return render_template("my_students.html", students=students)


@app.route("/send-email/<email>", methods=['GET'])
def send_email_page(email):
    return render_template('send_email.html', email=email)


@app.route('/send-email', methods=['POST'])
@login_required
def send_email():
    teacher_email = current_user.email
    student_email = request.form['email']
    message_content = request.form['message']

    new_message = Message(teacher_email=teacher_email, student_email=student_email, message=message_content)
    db.session.add(new_message)
    db.session.commit()

    flash('Message sent successfully!', 'success')
    return redirect(url_for('students'))


@app.route('/upload', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        if 'file' not in request.files:
            return 'No file part'
        file = request.files['file']
        if file.filename == '':
            return 'No selected file'
        if file:
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

            # Save the file path and other details to the database
            post = Posts(
                subject_name=request.form['subject_name'],
                grade=request.form['grade'],
                Class=request.form['Class'],
                start_date=request.form['start_date'],
                end_date=request.form['end_date'],
                notification=request.form['notification'],
                title=request.form['title'],
                content=request.form['content'],
                pdf_path=filename,
                author_id=request.form['author_id'],
                subject_id=request.form['subject_id']
            )
            db.session.add(post)
            db.session.commit()
            return redirect(url_for('upload_file'))
    return render_template('upload.html')


@app.route("/my_subjects")
@login_required
def my_subjects():
    print(f"Current User ID: {current_user.id}")  # Debug statement
    print(f"Current User Role: {current_user.role}")  # Debug statement

    if current_user.role == 'student':
        all_subjects = Subjects.query.all()
        current_user_grade = current_user.grade
        filtered_subjects = [subject for subject in all_subjects if subject.grade == current_user_grade]
        return render_template("my_subjects.html", subjects=filtered_subjects)

    elif current_user.role == 'teacher':
        teacher = Users.query.filter_by(id=current_user.id).first()
        teacher_name = teacher.name
        print(teacher_name)
        if teacher:
            filtered_subjects = Subjects.query.filter_by(teacher_name=teacher_name).all()
            return render_template("my_subjects_teacher.html", subjects=filtered_subjects)
        else:
            print("Teacher record not found.")  # Debug statement
            return redirect("/")

    else:
        print("Role not recognized.")  # Debug statement
        return redirect("/")


@app.route("/sessions")
def sessions():
    return render_template("sessions.html")


@app.route("/assessments")
def assessments():
    return render_template("assessments_assignments.html")


@app.route("/quizzes")
@login_required
def quizzes():
    if current_user.role == "student" or "parent":
        return render_template("quizzes.html")

    if current_user.role == "teacher" or "admin":
        return render_template("quiz_creation.html")
    else:
        return redirect(url_for('unauthorized'))


@app.route("/unauthorized")
def unauthorized():
    return "You are not authorized to view this page.", 403


@app.route("/subjects", methods=['GET', 'POST'])
@login_required
def subject():
    if current_user.role == "teacher":
        if request.method == 'POST':
            title = request.form.get('title')
            content = request.form.get('content')
            subject_name = request.form.get('subject_name')
            grade = request.form.get('grade')
            Class = request.form.get('Class')
            start_date = request.form.get('start_date')
            end_date = request.form.get('end_date')
            notification = request.form.get('notification')
            file = request.files.get('file')

            if file:
                filename = secure_filename(file.filename)
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

                # Save the file path and other details to the database
                new_post = Posts(
                    subject_name=subject_name,
                    grade=grade,
                    Class=Class,
                    start_date=start_date,
                    end_date=end_date,
                    notification=notification,
                    title=title,
                    content=content,
                    file_path=filename,
                    author_id=current_user.id,
                    subject_id=request.form.get('subject_id')
                )
                db.session.add(new_post)
                db.session.commit()

                if notification:  # If the checkbox is checked, send a notification
                    students = Users.query.filter_by(role='student', grade=grade).all()
                    for student in students:
                        send_notification(student.id, f"New post added to {subject_name}: {title}")

                return redirect(url_for('dashboard'))

        teachers = Teacher.query.all()
        return render_template('subject_creation.html', teachers=teachers)

    return redirect(url_for('unauthorized'))


# Route to view subject details dynamically
# Route to view subject details dynamically
@app.route('/view_subject/<int:subject_id>')
@login_required
def view_subject(subject_id):
    subject = Subjects.query.get_or_404(subject_id)

    if current_user.role == "student":
        posts = Posts.query.filter_by(subject_name=subject.name, grade=subject.grade).all()
        return render_template("view_subject.html", subject=subject, posts=posts)
    elif current_user.role == "teacher":
        # Check if the current teacher is assigned to the subject
        if subject.teacher_id == current_user.id:
            posts = Lessons.query.filter_by(name=subject.name).all()
            return render_template("view_subject_teacher.html", subject=subject, posts=posts)
        else:
            flash("You are not assigned to this subject.", "danger")
            return redirect(url_for('dashboard'))
    else:
        flash("You do not have the necessary permissions to view this page.", "danger")
        return redirect(url_for('dashboard'))


@app.route('/view_teacher/<int:id>')
def view_teacher(id):
    teacher = Teacher.query.filter_by(id=id).first()

    if not teacher:
        abort(404)  # If teacher is not found, return a 404

    return render_template("view_teacher.html", teacher_name=teacher.name, teacher=teacher)


@app.route("/profile")
@login_required
def profile():
    return render_template("profile.html")


@app.route("/setting")
@login_required
def setting():
    return render_template("profile-settings.html")


@app.route("/setting/security")
def security():
    return render_template("profile-security.html")


@app.route("/setting/notification")
def notification():
    return render_template("profile-notification.html")


@app.route('/create_subject', methods=['GET', 'POST'])
@login_required
def create_subject():
    if request.method == 'POST':
        data = request.get_json()
        subject_name = data.get('name')
        grade = data.get('grade')

        if not subject_name or not grade:
            return jsonify({'error': 'Subject name and grade are required'}), 400

        new_subject = Subjects(name=subject_name, grade=grade, teacher_id=current_user.id,teacher_name=current_user.name)
        db.session.add(new_subject)
        db.session.commit()

        return jsonify({'message': 'Subject created successfully'}), 201
    return render_template('create_subject.html')


@app.route('/create_lesson/<int:subject_id>', methods=['GET', 'POST'])
@login_required
def create_lesson(subject_id):
    subject = Subjects.query.get_or_404(subject_id)

    # Ensure only the assigned teacher can add lessons
    if subject.teacher_id != current_user.id:
        return jsonify({'error': 'You do not have permission to add a lesson to this subject'}), 403

    if request.method == 'POST':
        lesson_name = request.form.get('lessonName')
        video_link = request.form.get('videoLink')
        grade = request.form.get('grade')

        # Validate required fields
        if not lesson_name or not video_link or not grade:
            return jsonify({'error': 'Lesson name, video link, and grade are required'}), 400

        # Create new lesson
        new_lesson = Lessons(name=lesson_name, subject_id=subject_id)
        db.session.add(new_lesson)
        db.session.commit()

        # Add video
        new_video = Videos(name=lesson_name, url=video_link, lesson_id=new_lesson.id)
        db.session.add(new_video)
        db.session.commit()

        return redirect("/dashboard")

    # GET request: render the form for creating a lesson
    return render_template('create_lesson.html', subject=subject)


UPLOAD_FOLDER = 'path/to/upload/folder'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Configuration for file uploads
UPLOAD_FOLDER = 'path/to/upload/folder'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure the upload folder exists
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)


@app.route('/create_file/<int:lesson_id>', methods=['GET', 'POST'])
@login_required
def create_file(lesson_id):
    lesson = Lessons.query.get_or_404(lesson_id)
    subject = Subjects.query.get(lesson.subject_id)

    if subject.teacher_id != current_user.id:
        return jsonify({'error': 'You do not have permi ssion to add a file to this lesson'}), 403

    if request.method == 'POST':
        if 'file' not in request.files:
            return jsonify({'error': 'No file part'}), 400

        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No selected file'}), 400

        if file:
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)

            new_file = Files(name=filename, path=file_path, lesson_id=lesson_id)
            db.session.add(new_file)
            db.session.commit()

            return jsonify({'message': 'File created successfully'}), 201

    return render_template('create_file.html', lesson=lesson)


if __name__ == "_main_":
     app.run(debug=True)